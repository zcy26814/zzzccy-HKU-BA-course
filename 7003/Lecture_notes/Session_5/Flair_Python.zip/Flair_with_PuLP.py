Products = ['Table','Chair']
Profits = {'Table':70,'Chair':50}
CarpentryHours = {'Table':4,'Chair':3}
PnVHours = {'Table':2,'Chair':1}
Resources = ['Carpentry','PnV']
ResHours = {'Carpentry':240,'PnV':100}

from pulp import *

prob = LpProblem("Flair_Furniture",LpMaximize)
production = LpVariable.dicts("Quantity",Products,lowBound=0)
prob += lpSum([production[i]*Profits[i] for i in Products]), "Total_Profit"
prob += lpSum([production[i]*CarpentryHours[i]
               for i in Products]) <= ResHours['Carpentry']
prob += lpSum([production[i]*PnVHours[i]
               for i in Products]) <= ResHours['PnV']
prob.solve()
print("The total profit =", value(prob.objective))
