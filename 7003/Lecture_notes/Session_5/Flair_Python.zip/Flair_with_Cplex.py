import cplex
prob = cplex.Cplex()
prob.objective.set_sense(prob.objective.sense.maximize)
prob.variables.add(names=["nTable", "nChair"],
                   obj=[70, 50])
prob.linear_constraints.add(names=["Carpentry_Constraint","P&V_Constraint"],
                            rhs=[240,100],
                            senses="LL")
rows=[0,0,1,1]
cols=[0,1,0,1]
vals=[4,3,2,1]
prob.linear_constraints.set_coefficients(zip(rows,cols,vals))
prob.solve()
# The following lines are for output only
print(); print("Solution status = ", prob.solution.get_status(), ":", end=' ')
print(prob.solution.status[prob.solution.get_status()])
print(); print("The objective value = %f" % (prob.solution.get_objective_value()))
numvar=prob.variables.get_num()
print(); print("The optimal solution is:")
for j in range(numvar):
    print("%s = %f " % (prob.variables.get_names(j), prob.solution.get_values(j)))
print(); print("Allowed range of variable bounds:")
print(prob.solution.sensitivity.bounds())
print(); print("Allowed range of objective function coefficients:")
print(prob.solution.sensitivity.objective())
print(); print("Allowed range of right-hand-side values:")
print(prob.solution.sensitivity.rhs())
numrows = prob.linear_constraints.get_num()
slack = prob.solution.get_linear_slacks()
sp = prob.solution.get_dual_values()
for i in range(numrows):
    print()
    print("Constraint %d (%s):" % (i+1, prob.linear_constraints.get_names(i)))
    print("Slack = %f; Shadow Price = %f" % (slack[i], sp[i]))
