from docplex.mp.model import Model

Problem = Model(name='FlairFurniture')

x1=Problem.continuous_var(lb=0,name='nTable')
x2=Problem.continuous_var(lb=0,name='nChair')

Problem.maximize(70*x1+50*x2)

Problem.add_constraint(4*x1+3*x2<=240)
Problem.add_constraint(2*x1+x2<=100)

Solution=Problem.solve()
Solution.display()
